
import WebDevelopment from './AboutWebDevelopment/WebDevelopment';
import './App.css';
import Contact from './Contact/Contact';
import Services from './Services/Services';
function App() {
  return (
    <div className="App">
      
      <Services />
      <WebDevelopment />
      {/* <Contact /> */}

    </div>
  );
}

export default App;
