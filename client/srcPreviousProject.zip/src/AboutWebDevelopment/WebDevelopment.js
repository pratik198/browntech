import React from "react";
import { Grid, Typography, Box, Paper } from "@mui/material";
import { FaReact, FaNodeJs, FaDatabase } from "react-icons/fa";
import { motion } from "framer-motion";

export default function WebDevelopment() {
  return (
    <Box sx={{ padding: 2, backgroundColor: "#091d36" }}>
      <Grid container spacing={2} marginTop="2rem">
        {/* Left Div */}
        <Grid item xs={12} md={7}>
          <Typography variant="h3" color="white" gutterBottom>
            About Web Development
          </Typography>
          <Typography
            variant="h5"
            textAlign="justify"
            padding="2rem"
            color="violet"
          >
            At BrownTech, we specialize in creating high-performance websites
            and web applications that drive digital success. Our web development
            services cover both front-end and back-end development, ensuring
            visually engaging and technically robust solutions.
          </Typography>
        </Grid>

        {/* Right Div */}
        <Grid item xs={12} md={5}>
          <Box
            component="img"
            sx={{
              width: "100%",
              height: "auto",
              borderRadius: 2,
            }}
            alt="Example Image"
            src="https://api.reliasoftware.com/uploads/web_development_is_important_176fa0618e.jpg"
          />
        </Grid>
      </Grid>

      {/* Section for Technology we cover */}
      <Typography variant="h3" color="white" marginTop="2rem" textAlign="center">
        Technology we Cover
      </Typography>
      <Grid container spacing={2} marginTop="1rem">
        {/* ReactJS */}
        <Grid item xs={12} md={4}>
          <motion.div
            whileHover={{
              scale: 1.05,
              backgroundColor: "#20232A",
              boxShadow: "0px 12px 20px rgba(0, 0, 0, 0.5)",
              transition: { duration: 0.3 },
            }}
            style={{ borderRadius: '8px' }}
          >
            <Paper
              sx={{
                padding: 4,
                textAlign: "center",
                backgroundColor: "#152532",
                color: "white",
                height: "30rem",
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                borderRadius: 2,
                position: 'relative',
                overflow: 'hidden',
                transition: 'background-color 0.3s ease',
              }}
            >
              <FaReact size={40} color="#61DBFB" />
              <Typography variant="h5" marginTop="1rem" color="violet">
                React.Js
              </Typography>
              <Typography
                variant="body1"
                fontSize="1.2rem"
                lineHeight="1.5"
                marginTop="1rem"
                textAlign="justify"
              >
                A powerful JavaScript library for building dynamic and responsive
                user interfaces. React.js enables efficient UI rendering and
                offers a component-based architecture, making it ideal for
                single-page applications.
              </Typography>
            </Paper>
          </motion.div>
        </Grid>

        {/* Node.js */}
        <Grid item xs={12} md={4}>
          <motion.div
            whileHover={{
              scale: 1.05,
              backgroundColor: "#20232A",
              boxShadow: "0px 12px 20px rgba(0, 0, 0, 0.5)",
              transition: { duration: 0.3 },
            }}
            style={{ borderRadius: '8px' }}
          >
            <Paper
              sx={{
                padding: 4,
                textAlign: "center",
                backgroundColor: "#152532",
                color: "white",
                height: "30rem",
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                borderRadius: 2,
                position: 'relative',
                overflow: 'hidden',
                transition: 'background-color 0.3s ease',
              }}
            >
              <FaNodeJs size={40} color="#3C873A" />
              <Typography variant="h5" marginTop="1rem" color="violet">
                Node.Js
              </Typography>
              <Typography
                variant="body1"
                fontSize="1.2rem"
                lineHeight="1.5"
                marginTop="1rem"
                textAlign="justify"
              >
                A runtime environment that allows you to execute JavaScript
                server-side. Node.js is perfect for building scalable network
                applications and real-time services.
              </Typography>
            </Paper>
          </motion.div>
        </Grid>

        {/* MongoDB */}
        <Grid item xs={12} md={4}>
          <motion.div
            whileHover={{
              scale: 1.05,
              backgroundColor: "#20232A",
              boxShadow: "0px 12px 20px rgba(0, 0, 0, 0.5)",
              transition: { duration: 0.3 },
            }}
            style={{ borderRadius: '8px' }}
          >
            <Paper
              sx={{
                padding: 4,
                textAlign: "center",
                backgroundColor: "#152532",
                color: "white",
                height: "30rem",
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                borderRadius: 2,
                position: 'relative',
                overflow: 'hidden',
                transition: 'background-color 0.3s ease',
              }}
            >
              <FaDatabase size={40} color="#47A248" />
              <Typography variant="h5" marginTop="1rem" color="violet">
                MongoDB
              </Typography>
              <Typography
                variant="body1"
                fontSize="1.2rem"
                lineHeight="1.5"
                marginTop="1rem"
                textAlign="justify"
              >
                A NoSQL database designed for scalability and flexibility. MongoDB
                allows you to store and manage large volumes of unstructured data
                with ease.
              </Typography>
            </Paper>
          </motion.div>
        </Grid>
      </Grid>
    </Box>
  );
}
