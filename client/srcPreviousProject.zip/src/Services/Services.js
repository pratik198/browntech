import React from "react";
import { Box, Grid, Typography, Paper } from "@mui/material";

export default function Services() {
  const serviceData = [
    {
      title: "Custom Website Development",
      img: "https://ecloudsoftware.in/blog/wp-content/uploads/2022/08/website-development-process-1.jpg",
      description: `We create fully custom websites from the ground up, ensuring that your brand stands out. Our designs are user-friendly, visually appealing, and optimized for performance.`,
    },
    {
      title: "24*7 Support",
      img: "https://img.freepik.com/premium-vector/web-page-design-templates-call-center-support-24-7-isometric-24-hours-open-customer-service-vector-illustration-customer-service-support-crm_589019-1453.jpg",
      description: `At BrownTech, our 24/7 support ensures your business is always up and running. With real-time monitoring, rapid issue resolution, and multichannel communication, our team is available around the clock to provide assistance whenever you need it.`,
    },
    {
      title: "Web Development",
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRbUJpkkAAgJhF5FfBvb510FODUc_qeAunA7Q&s",
      description: `At BrownTech, we provide comprehensive web development services that deliver exceptional user experiences and robust functionality. Our team specializes in both front-end and back-end development, ensuring responsive, secure, and scalable websites tailored to your business needs.`,
    },
    {
      title: "100% Responsive Website",
      img: "https://img.freepik.com/free-vector/gradient-responsive-website-design-set_23-2149538364.jpg",
      description: `Every website we build is mobile-first and fully responsive, ensuring an optimal user experience across all devices, from desktops to smartphones and tablets.`,
    },
    {
      title: "Logo Designs",
      img: "https://cdn.dribbble.com/users/45787/screenshots/6825031/concreetshot_4x.png?resize=400x300&vertical=center",
      description: `Our logo design service is for multiple industries, such as real estate, education, financial institutions, food, hospitality, information technology, fashion, and more. We also provide custom logo design services.`,
    },
  ];

  const clientData = [
    {
      title: "Portfolio",
      description:
        "Showcase your work with BrownTech's portfolio services. We create visually stunning, user-friendly portfolio websites that highlight your achievements, projects, and skills. Our customized designs ensure your portfolio stands out, engaging potential clients and employers while reflecting your unique brand and expertise. Whether you're an individual or a business, we help you make a lasting impression online.",
      img: "https://png.pngtree.com/png-vector/20190228/ourmid/pngtree-vector-portfolio-icon-png-image_711172.jpg",
    },
    {
      title: "Online Learning Platforms",
      description:
        "We build dynamic, user-friendly online learning platforms designed to enhance educational experiences. Our platforms offer seamless navigation, interactive content delivery, and robust assessment tools, ensuring an engaging and efficient learning environment. With scalable solutions, we empower educators and learners to connect anytime, anywhere.",
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTtb5gib4gqdc_tMw8B-3sierNKbjkAo1UzIQ&s",
    },
    {
      title: "Social Media Platforms",
      description:
        "We design and develop innovative social media platforms that foster community engagement and connectivity. Our solutions focus on creating intuitive interfaces, scalable features, and secure environments, enabling users to interact, share, and connect seamlessly.",
      img: "https://banner2.cleanpng.com/20180804/zzf/e96fa73824f727cb818ffb4dbcdbbc12.webp",
    },
    {
      title: "Real-time Chat Applications",
      description:
        "We create cutting-edge real-time chat applications that facilitate instant, seamless communication. Our solutions offer live messaging, user-friendly interfaces, and reliable performance, ensuring smooth and effective interactions for your users.",
      img: "https://cdn-icons-png.freepik.com/256/4709/4709679.png?semt=ais_hybrid",
    },
    {
      title: "Travel and Tourism Websites",
      description:
        "At BrownTech, we design intuitive travel and tourism applications that streamline trip planning and enhance travel experiences. Our solutions offer features like real-time booking, interactive maps, and personalized recommendations, making travel seamless and enjoyable.",
      img: "https://cdn-icons-png.flaticon.com/512/5333/5333707.png",
    },
    {
      title: "E-commerce Applications",
      description:
        "create powerful, secure, and scalable e-commerce platforms that drive online sales and enhance user experience. From seamless product browsing to secure checkout and payment integrations, our solutions are tailored to meet your business needs, helping you reach more customers and grow your brand.",
      img: "https://cdn-icons-png.freepik.com/256/10364/10364605.png?semt=ais_hybrid",
    },
  ];

  return (
    <Box sx={{ padding: 2, backgroundColor: "#091d36" }}>
      {/* Heading */}
      <Typography variant="h3" align="center" color="white" gutterBottom>
        Our Services
      </Typography>

      {/* Responsive Grid */}
      <Grid container spacing={4} justifyContent="center">
        {serviceData.map((service, index) => (
          <Grid
            item
            xs={12}
            sm={6}
            md={4}
            key={index}
            sx={{ mb: { xs: 4, md: 4 }, position: "relative" }}
          >
            <Paper
              sx={{
                position: "relative",
                overflow: "hidden",
                borderRadius: "8px",
                height: "auto",
                "&:hover .imageBox": {
                  transform: "translateY(-100%)",
                },
                "&:hover .titleOverlay": {
                  opacity: 0,
                },
                "&:hover .textOverlay": {
                  transform: "translateY(0)",
                  opacity: 1,
                },
              }}
            >
              {/* Image */}
              <Box
                className="imageBox"
                component="img"
                src={service.img}
                alt={service.title}
                sx={{
                  width: "100%",
                  height: "20rem",
                  objectFit: "cover",
                  transition: "transform 0.5s ease-in-out",
                }}
              />

              {/* Title Overlay (Visible initially) */}
              <Box
                className="titleOverlay"
                sx={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  width: "100%",
                  height: "100%",
                  backgroundColor: "rgba(0, 0, 0, 0.4)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "white",
                  transition: "opacity 0.5s ease-in-out",
                  zIndex: 1,
                }}
              >
                <Typography variant="h5">{service.title}</Typography>
              </Box>

              {/* Text Overlay on Hover */}
              <Box
                className="textOverlay"
                sx={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  width: "auto", // Control width to ensure consistent starting and ending points
                  height: "80%",
                  backgroundColor: "#091d36",
                  color: "white",
                  padding: "1rem",
                  border: "1rem solid white",
                  transform: "translateY(100%)", // Start out of view
                  transition:
                    "transform 0.5s ease-in-out, opacity 0.5s ease-in-out",
                  opacity: 0,
                  zIndex: 2,
                  display: "flex",
                  textAlign: "justify", // Align text to the left
                  justifyContent: "jusfity", // Centers the text horizontally inside the box
                  alignItems: "center", // Centers the text vertically inside the box
                }}
              >
                <Typography
                  variant="body1"
                  sx={{
                    width: "100%", // Ensure the text spans the full width of the container
                    whiteSpace: "pre-wrap", // Handle multiline text with proper line breaks
                  }}
                >
                  {service.description}
                </Typography>
              </Box>
            </Paper>
          </Grid>
        ))}
      </Grid>

      <Typography
        variant="h3"
        align="center"
        color="white"
        gutterBottom
        marginTop="4rem"
      >
        Serving our clients across the <br /> diverse industries.
      </Typography>

      <Grid container spacing={4}>
        {clientData.map((client, index) => (
          <Grid item xs={12} sm={6} key={index}>
            <Paper
              sx={{
                padding: "2rem",
                backgroundColor: "#152532",
                color: "white",
                borderRadius: "8px",
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
                minHeight: "22rem",
              }}
            >
              <Grid container alignItems="center" spacing={2}>
                {/* Left side: Icon */}
                <Grid
                  item
                  xs={4}
                  sx={{ display: "flex", justifyContent: "center" }}
                >
                  {" "}
                  <Box
                    component="img"
                    src={client.img}
                    alt={client.title}
                    sx={{ width: "80px", height: "80px" }} // Adjust image size
                  />{" "}
                  {/* Adjust icon size here */}
                </Grid>

                {/* Right side: Client Heading and Description */}
                <Grid item xs={8}>
                  <Typography variant="h5" textAlign={"left"} color="#68b3ac">
                    {client.title}
                  </Typography>
                  <Typography variant="h6" textAlign="justify">
                    {client.description}
                  </Typography>
                </Grid>
              </Grid>
            </Paper>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}
